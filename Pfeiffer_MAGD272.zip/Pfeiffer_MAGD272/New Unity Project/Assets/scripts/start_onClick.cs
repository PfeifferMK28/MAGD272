﻿using UnityEngine;
using System.Collections;

public class start_onClick : MonoBehaviour {

    public void OnMouseDown()
    {
        Application.LoadLevel("gameScene");
    }

}
