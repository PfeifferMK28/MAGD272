﻿using UnityEngine;
using System.Collections;

public class statsManager : MonoBehaviour {

    public static int lives;
    public static int score;
    public static float health;
    public static string userName;
    public static int charisma;
}
