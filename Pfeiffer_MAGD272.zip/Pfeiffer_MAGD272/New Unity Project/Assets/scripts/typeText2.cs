﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class typeText2 : MonoBehaviour
{

    public string typedText = "What are you going to name your cat?";
    public string typedText2 = "Happy Birthday, Merlin!";
    public float interLetterTime;
    public Text targetTextWindow;

    public InputField userInputField;

    // Use this for initialization
    void Start()
    {
        StartCoroutine(addText(typedText));

    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator addText(string text)
    {
        int textLength = text.Length;
        for (int i = 0; i < textLength + 1; i++)
        {
            targetTextWindow.text = text.Substring(0, i);
            yield return new WaitForSeconds(interLetterTime);
        }
    }

    public void storeUserName()
    {
       statsManager.userName = userInputField.text;
        userInputField.text = "Great Name!";
        StartCoroutine(addText("Hi " + statsManager.userName + " it's nice to meet you!"));

    }

}
