﻿using UnityEngine;
using System.Collections;

public class DontDestroyAudio : MonoBehaviour {
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
}
