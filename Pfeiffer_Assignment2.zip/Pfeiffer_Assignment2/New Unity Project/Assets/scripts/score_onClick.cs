﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class score_onClick : MonoBehaviour {

    public void OnMouseDown()
    {
        Application.LoadLevel("highScore"); } 
  }
